import React from "react";
import "./Menu.css";
import { menuData } from '../../data/Menu';

function Menu() {
  return (
    <div className="menu-container">
      <div className="menu-grid">
        {menuData.map((item, index) => (
          <div key={index} className="menu-item">
            <img src={item.image} alt="" />
            <span>{item.name}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Menu;