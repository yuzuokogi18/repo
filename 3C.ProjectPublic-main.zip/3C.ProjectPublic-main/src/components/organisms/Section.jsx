import Grid from "../molecules/Grid";
import Fondo from "../molecules/Fondo";
import Menu from "../molecules/Menu";
import Description from "../molecules/Description";
import Contacto from "../molecules/Contacto";
import Contenedor from "../molecules/Contenedor";







function Section() {
    return (
    <>
        <Grid></Grid>  
        <Fondo></Fondo>
        <Menu></Menu>
        <Description></Description>
        <Contacto></Contacto>
        <Contenedor></Contenedor>
       
    </>)
}

export default Section;