export const descriptionData = {
    text: "El Restaurante Raudales está abierto al público desde el año 1997, ofreciéndoles siempre calidad y sabor. Podrán encontrar carnes asadas, mariscos, menú variado del dia, platillos a la carta, caldos variados todos los días de la semana, horneando los fines de semana y los días 15 y 30 de cada mes les ofrecemos exquisita birria de borrego, así como también nuestras famosas charolas surtidas de carnes y mariscos. Atendido amablemente por sus propietarios..",
    image: "chile.jpg"
  };
  